/* global chrome */

// Store scraped data in chrome storage
let scrapedData = null;
let connexPhoneNumber = null; // Store the Connex phone number separately

// 🔁 Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SCRAPE_DATA") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0].id;

      chrome.scripting.executeScript(
        {
          target: { tabId: tabId },
          files: ["content.js"],
        },
        () => {
          chrome.tabs.sendMessage(tabId, { type: "SCRAPE_DATA" }, (response) => {
            if (chrome.runtime.lastError || !response || !response.success) {
              sendResponse({ status: "Error scraping data." });
              return;
            }

            scrapedData = response.data;
            connexPhoneNumber = response.connexPhone;

            chrome.storage.local.set(
              { scrapedData: scrapedData, connexPhone: connexPhoneNumber },
              () => {
                sendResponse({
                  status: "Data scraped!",
                  data: scrapedData,
                  phone: connexPhoneNumber,
                });
              }
            );
          });
        }
      );
    });

    return true; // Keep sendResponse alive
  }

  if (msg.type === "SAVE_PHONE" && msg.phone) {
    connexPhoneNumber = msg.phone;
    chrome.storage.local.set({ connexPhone: msg.phone }, () => {
      console.log("[MacroMate BG] ☎️ Connex phone saved to storage by background.");
    });
  }

  if (msg.type === "PASTE_DATA") {
    chrome.storage.local.get(["scrapedData", "connexPhone"], (result) => {
      const dataToPaste = result.scrapedData;
      const phoneToPaste = result.connexPhone;

      if (!dataToPaste && !phoneToPaste) {
        sendResponse({ status: "❌ Error: No data found to paste." });
        return;
      }

      console.log("📋 Scraped Data to Paste:", dataToPaste);
      console.log("📞 Phone Number to Paste:", phoneToPaste);

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = tabs[0].id;

        chrome.tabs.sendMessage(
          tabId,
          { type: "FILL_ZENDESK", data: dataToPaste, phone: phoneToPaste },
          (response) => {
            console.log(response);
            sendResponse({ status: "Data pasted!" });
          }
        );
      });
    });

    return true;
  }

  if (msg.type === "GET_SCRAPED_DATA") {
    chrome.storage.local.get(["scrapedData", "connexPhone"], (result) => {
      sendResponse({
        data: result.scrapedData,
        phone: result.connexPhone,
      });
    });

    return true;
  }
});
